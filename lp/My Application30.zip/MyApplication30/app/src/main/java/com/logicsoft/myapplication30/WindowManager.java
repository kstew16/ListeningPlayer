package com.logicsoft.myapplication30;

class WindowManager {
    public static Object LayoutParams;
}
