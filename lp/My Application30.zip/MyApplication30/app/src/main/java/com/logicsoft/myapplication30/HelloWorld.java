package com.logicsoft.myapplication30;
import android.util.Log;

public class HelloWorld
{
    public static void main(String[] args) {
        System.out.println("hello World");
        Log.e("hello", "world");
    }
}
