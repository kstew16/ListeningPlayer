//package kr.logicsoft.listeningplayer;
package com.logicsoft.myapplication30;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

//import kr.logicsoft.listeningplayer.util.ContextUtil;

public class MainActivity extends Activity
{

	public static MainActivity ins;
	public static int playmode=0;
	private static String TAG = "logicsoft";

	// private VideoAdapter mAdapter = null;
	// private List<VideoData> mVideoList = null;
	private LinearLayout mselectmode;
	private LinearLayout mHelpMessage;
	private Button mStandardButton;
	private Button mMixButton;
	private Button mNonButton;
	private Button mMyvideoButton;
	private Button mBackButton;
	private ImageButton mButtonHelp;
	private ImageButton mBackButton2;
	private ImageButton mConvertButton;


	private ListView mListView = null;
	private String urls[][] = {
			{
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVVkxlbkJuc1lIc1k",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVSFJBTUs0N0NscFU",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVQmVkR1ZHWFhBVnc",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVUVA1X3NuX2hrbmc",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVYzlLaDBNaThhODQ",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVNjItdE5tZE9NZXc",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVWWk2bExHM0ExNHc",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVT21HeGt5UlBvWDA",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVUjJzMi1UX2F0N00",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVS2EzUnRueFpsU3c"
			},
			{
				"American_Ultra_Red_Band_Trailer.mp4",
				"Before_We_Go_Trailer.mp4",
				"Cooties_Trailer.mp4",
					"Friends.1x01.The.One.Where.Monica.Gets.A.New.Roommate-JOG.avi",
				"Cop_Car_Trailer.mp4",
				"DeadPool_Trailer.mp4",
				"KungFu_Panda3_Trailer.mp4",
				"Mad_Max_Trailer.mp4",
				"The_Hunger_Games-Mockingjay-Part 2_Trailer.mp4",
				"The_Martian_Trailer.mp4",
				"The_5th_Wave_Trailer.mp4"
			}
			};
	
	
	private String subs[][] = {
			{
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVWktRcGhLWDZkMlE",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVZ09pdk9IWlVSZVU",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVRG5zNk5pQUw4T00",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVbkhueHVWUVJXODQ",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVa3BoanZyZ0VLbkk",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVenY1Y1JQQmItZkk",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVWTE5TVVyZlFVLXM",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVbmZDdVlVbTBFdUU",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVZUxYZ2lZMDZSajQ",
				"https://docs.google.com/uc?export=download&id=0B-HB7J8-HTfVR08yMVJVbVdSQU0"}, 
			{
				"American_Ultra_Red_Band_Trailer.json",
				"Before_We_Go_Trailer.json",
				"Cooties_Trailer.json",
				"Friends.1x01.The.One.Where.Monica.Gets.A.New.Roommate-JOG.json",
				//"Cop_Car_Trailer.json",
				"DeadPool_Trailer.json",
				"KungFu_Panda3_Trailer.json",
				"Mad_Max_Trailer.json",
				"The_Hunger_Games-Mockingjay-Part 2_Trailer.json",
				"The_Martian_Trailer.json",
				"The_5th_Wave_Trailer.json"
			}
			};
	
	public String movie_url;
	public String subtitle_url;
	public String MOVIE_SAVE_PATH;
	public String MOVIE_SAVE_NAME;
	public String SUBTITLE_SAVE_NAME;
	public File file;
	public File subfile;
	public String prjName = "ListeningPlayer";
	public long urlNum;
	
	ArrayList<TitleList> Titles = new ArrayList<TitleList>();


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		// mAdapter = new VideoAdapter(getApplicationContext());
		// mVideoList = ContextUtil.getVideoList(getApplicationContext());
		mselectmode = (LinearLayout)findViewById(R.id.selectmode);
		mHelpMessage = (LinearLayout)findViewById(R.id.HelpMessage);
		mStandardButton = (Button)findViewById(R.id.StandardButton);
		mMixButton = (Button)findViewById(R.id.MixButton);
		mNonButton = (Button)findViewById(R.id.NonButton);
		mMyvideoButton = (Button)findViewById(R.id.Myvideo);
		mBackButton = (Button)findViewById(R.id.BackButton);
		mBackButton2 = (ImageButton)findViewById(R.id.BackButton2);
		mButtonHelp = (ImageButton)findViewById(R.id.ButtonHelp);
		mConvertButton = (ImageButton)findViewById(R.id.convertbutton);

		ins = this;

		mListView = (ListView) findViewById(R.id.listView);

		Log.d(TAG, "hello log");

		Log.e(TAG, "hellp errors");

		final Builder m= new AlertDialog.Builder(this);
		
		// mListView.setAdapter(mAdapter);

		Titles.add(new TitleList(0, "American Ultra Red Band Trailer"));
		Titles.add(new TitleList(1, "Before We Go Trailer"));
		Titles.add(new TitleList(2, "Cooties Trailer"));
		Titles.add(new TitleList(3, "Friends"));
		Titles.add(new TitleList(4, "DeadPool Trailer"));
		Titles.add(new TitleList(5, "Kungfu Panda3 Trailer"));
		Titles.add(new TitleList(6, "Mad Max Trailer"));
		Titles.add(new TitleList(7, "The Hunger Games-Mockingjay Part 2 Trailer"));
		Titles.add(new TitleList(8, "The Martian Trailer"));
		Titles.add(new TitleList(9, "The 5th Wave Trailer"));
		

		
		mListView.setAdapter(new CustomArrayAdapter(this,
				R.layout.listitem_download, Titles));

		mListView.setOnItemClickListener(mItemClickListener);
		mMyvideoButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this, UserFileList.class);
				startActivity(intent);
				overridePendingTransition(R.anim.fade, R.anim.hold);
				finish();
			}
		});
		
		mConvertButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				m.setMessage("���� ���� ���Դϴ�.\n���ŷο�ð�����\nhansangwon_@naver.com \n����� ���� �ֽø� ��ȯ�ؼ� �����帮�ڽ��ϴ�.");
				m.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});

			}
		});

		mBackButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mHelpMessage.setVisibility(View.GONE);
			}
		});
		
		File sdpath = Environment.getExternalStorageDirectory();
		MOVIE_SAVE_PATH = sdpath.getPath() + "/" + prjName;
		Log.e("MOVIE_SAVE_PATH", MOVIE_SAVE_PATH);

		File savePath = new File(MOVIE_SAVE_PATH);
		System.out.println("savePath_exists : " + savePath.exists());
		Log.d(TAG,"1");
		if (!savePath.exists())
		{
			try
			{
				savePath.mkdirs();
				System.out.println("savePath_Make : " + savePath.mkdirs());
			} catch (Exception er)
			{
				Log.e("Make Error", "Error : " + er);
			}
		}

		Log.d(TAG,"2");
		/*
	
		
			subtitle_url = subs[0][Titles.get(position).id];
			SUBTITLE_SAVE_NAME = subs[1][Titles.get(position).id];

			file = new File(MOVIE_SAVE_PATH + "/" + SUBTITLE_SAVE_NAME);
			Log.e("filepath", file.getPath());
			System.out.println("fileExists : " + file.exists());

			if (!file.exists())
			{
		//		Log.e("movie_url", movie_url);
				startDownload();
			}
			
		*/
		mselectmode.setVisibility(View.GONE);
		mHelpMessage.setVisibility(View.GONE);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	public OnItemClickListener mItemClickListener = new OnItemClickListener()
	{
		public void onItemClick(AdapterView<?> parent, View v, int position,
				long id)
		{
			
			String urlnumber = Integer.toString(Titles.get(position).id);
			Log.e("urlnumber", urlnumber);

			//show("mItemClickListner");
			// show("file : " + file.getPath());

            //Intent intent = new Intent(MainActivity.this,VideoActivity.class);
            // intent.putExtra("path", mVideoList.get(position).getPath());
            // intent.putExtra("path", file.getPath());
            //startActivity(intent);

			
		//	String urlNum1 = Integer.toString(Titles.get(position).id);
		//	Log.e("urlNum", urlNum1);
			movie_url = urls[0][Titles.get(position).id];

			MOVIE_SAVE_NAME = urls[1][Titles.get(position).id];

			file = new File(MOVIE_SAVE_PATH + "/" + MOVIE_SAVE_NAME);
			Log.e("filepath", file.getPath());
			System.out.println("fileExists : " + file.exists());
			
			subtitle_url = subs[0][Titles.get(position).id];
			SUBTITLE_SAVE_NAME = subs[1][Titles.get(position).id];

			subfile = new File(MOVIE_SAVE_PATH + "/" + SUBTITLE_SAVE_NAME);
			Log.e("filepath", file.getPath());
			System.out.println("fileExists : " + file.exists());

//            show("file : " + file.getPath());






            Intent intent = new Intent(MainActivity.this,VideoActivity.class);
            // intent.putExtra("path", mVideoList.get(position).getPath());
            intent.putExtra("path", file.getPath());
            startActivity(intent);
		}
	};

	private void setModeViewEvent()
	{
		mBackButton2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mselectmode.setVisibility(View.GONE);
			}
		});
		
		mButtonHelp.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mHelpMessage.setVisibility(View.VISIBLE);
			}
		});
		
		mStandardButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				playmode=1;
				mselectmode.setVisibility(View.GONE);
				Intent intent = new Intent(MainActivity.this,VideoActivity.class);
				// intent.putExtra("path", mVideoList.get(position).getPath());
				intent.putExtra("path", file.getPath());
				startActivity(intent);
			}
		});
		
		
		mMixButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				playmode=2;
				mselectmode.setVisibility(View.GONE);
				Intent intent = new Intent(MainActivity.this,VideoActivity.class);
				// intent.putExtra("path", mVideoList.get(position).getPath());
				intent.putExtra("path", file.getPath());
				startActivity(intent);
			}
		});
		
		mNonButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				playmode=3;
				mselectmode.setVisibility(View.GONE);
				Intent intent = new Intent(MainActivity.this,VideoActivity.class);
				// intent.putExtra("path", mVideoList.get(position).getPath());
				intent.putExtra("path", file.getPath());
				startActivity(intent);
			}
		});
	}
	
	public class TitleList
	{
		public String title;
		public int id;

		public TitleList()
		{
		}

		public TitleList(int id, String title)
		{
			this.id = id;
			this.title = title;
		}
	}

	// CustomArrayAdapter Set

	public class CustomArrayAdapter extends ArrayAdapter<TitleList>
	{
		private ArrayList<TitleList> titleList = null;

		public CustomArrayAdapter(Context c, int textViewResourceId,
				ArrayList<TitleList> arrays)
		{
			super(c, textViewResourceId, arrays);
			LayoutInflater.from(c);
		}

		@Override
		public int getCount()
		{
			return super.getCount();
		}

		@Override
		public TitleList getItem(int position)
		{
			return super.getItem(position);
		}

		@Override
		public long getItemId(int position)
		{
			return super.getItemId(position);
		}

		@Override
		public View getView(int position, View convertview, ViewGroup parent)
		{

			View v = convertview;

			if (v == null)
			{
				v = getLayoutInflater().inflate(R.layout.listitem_download, null);
			}
			TextView tv_Title = (TextView) v.findViewById(R.id.Tv_Title);
			tv_Title.setText(getItem(position).title);
			urlNum = getItemId(position);
			tv_Title.setTextColor(Color.BLACK);
			return v;
		}

		public void setArrayList(ArrayList<TitleList> arrays)
		{
			this.titleList = arrays;
		}

		public ArrayList<TitleList> getArrayList()
		{
			return titleList;
		}
	}
	
	class DownloadFileAsync extends AsyncTask<String, String, String>
	{

		private ProgressDialog mDlg;

		@Override
		protected void onPreExecute()
		{
			mDlg = new ProgressDialog(MainActivity.this);
			mDlg.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mDlg.setMessage("Downloading...");
			mDlg.setCancelable(false);
			mDlg.show();

			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params)
		{
			// String Length = null;
			int count = 0;

			try
			{
				URL url = new URL(movie_url);
				URLConnection con = url.openConnection();
				con.connect();

				int lengthOfFile = con.getContentLength();
				Log.e("Length of file", "length = " + lengthOfFile);
				Log.e("getPath", file.getPath());

				InputStream input = new BufferedInputStream(url.openStream());
				OutputStream output = new FileOutputStream(file.getPath());

				byte data[] = new byte[1024];

				long total = 0;

				while ((count = input.read(data)) != -1)
				{
					total += count;

					publishProgress("" + (int) ((total * 100) / lengthOfFile));

					output.write(data, 0, count);
				}
				output.flush();
				output.close();
				input.close();
			} catch (Exception e)
			{
				Log.e("VideoManager", "Error: " + e);
			}
			// TODO Auto-generated method stub
			return params[0];
		}

		@Override
		protected void onProgressUpdate(String... progress)
		{
			// TODO Auto-generated method stub
						
			mDlg.setProgress(Integer.parseInt(progress[0]));
		}

		@Override
		protected void onPostExecute(String result)
		{
			mDlg.setCancelable(true);
			mDlg.dismiss();
			Toast.makeText(MainActivity.this, "File Download Complete", Toast.LENGTH_LONG).show();
		}
	}
	
	class DownloadSubtitleFileAsync extends AsyncTask<String, String, String>
	{

		private ProgressDialog mDlg;

		@Override
		protected void onPreExecute()
		{
			mDlg = new ProgressDialog(MainActivity.this);
			mDlg.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mDlg.setMessage("Downloading...");
			mDlg.setCancelable(false);
			mDlg.setProgress(0);
			mDlg.show();

			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params)
		{
			// String Length = null;

			int count = 0;

			try
			{
				params[0]=subtitle_url;
				URL url = new URL(subtitle_url);
				URLConnection con = url.openConnection();
				con.connect();

				int lengthOfFile = con.getContentLength();
				Log.e("Length of file", "length = " + lengthOfFile);
				Log.e("getPath", subfile.getPath());

				InputStream input = new BufferedInputStream(url.openStream());
				OutputStream output = new FileOutputStream(subfile.getPath());

				byte data[] = new byte[1024];

				long total = 0;
				//mDlg.setProgress((int) ((total * 100) / lengthOfFile));
				while ((count = input.read(data)) != -1)
				{
					total += count;

					//publishProgress("" + (int) ((total * 100) / lengthOfFile));
					output.write(data, 0, count);
				}
				output.flush();
				output.close();
				input.close();

			} catch (Exception e)
			{
				Log.e("VideoManager", "Error: " + e);
			}
			// TODO Auto-generated method stub
			return null;
		}
		protected void onProgressUpdate(Integer... progress)
		{
			mDlg.setProgress(progress[0]);
			// TODO Auto-generated method stub
		}

		@Override
		protected void onPostExecute(String result)
		{
			mDlg.setCancelable(true);
			mDlg.dismiss();
			Toast.makeText(MainActivity.this, "Subtitle Download Complete",
					Toast.LENGTH_LONG).show();
		}
	}

	private void startMovieDownload()
	{
		Log.e("movie_url", movie_url);
		String url = movie_url;
		new DownloadFileAsync().execute(url);
	}
	
	private void startSubtitleDownload()
	{
		String url = subtitle_url;
		new DownloadSubtitleFileAsync().execute(url);
	}
	
	public void onBackPressed() {
		// TODO Auto-generated method stub
		// super.onBackPressed(); //������ �����

		Builder d = new AlertDialog.Builder(this);
		d.setMessage("���� �����Ͻðڽ��ϱ�?");
		d.setPositiveButton("��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// process��ü ����
				finish();
			}
		});
		d.setNegativeButton("�ƴϿ�", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
			}
		});
		d.show();
	} 


	// public class DownloadThread extends Thread
	// {
	// private String movieDownURL;
	// public DownloadThread(String tempURL)
	// {
	// this.movieDownURL = tempURL;
	// Log.e("tempURL", tempURL);
	// }
	// @Override
	// public void run() {
	// int read, size = 0;
	// URL mURL;
	//
	// try {
	// mURL = new URL(movieDownURL);
	// HttpURLConnection conn = (HttpURLConnection) mURL.openConnection();
	// int len = conn.getContentLength();
	// byte[] tempByte = new byte[len];
	// InputStream is = conn.getInputStream();
	// OutputStream fos = new FileOutputStream(file);
	//
	// while (!isInterrupted()) {
	// read = is.read(tempByte);
	// if (read <= 0) {
	// break;
	// }
	//
	// size += read;
	// fos.write(tempByte, 0, read);
	// }
	//
	// is.close();
	// fos.close();
	// conn.disconnect();
	// } catch (Exception e) {
	// }
	// }
	// }

	// public class VideoAdapter extends BaseAdapter {
	// private Context mContext;
	//
	// public VideoAdapter(Context c) {
	// mContext = c;
	// }
	//
	// public int getCount() {
	// return mVideoList.size();
	// }
	//
	// public Object getItem(int position) {
	// return mVideoList.get(position);
	// }
	//
	// public long getItemId(int position) {
	// return mVideoList.get(position).getId();
	// }
	//
	// public View getView(int position, View convertView, ViewGroup parent) {
	// View v = convertView;
	// VideoData video = mVideoList.get(position);
	// if (v == null) {
	// v = getLayoutInflater().inflate(R.layout.listitem_video, null);
	// }
	// ImageView ivThumbnail = (ImageView)v.findViewById(R.id.ivThumbnail);
	// TextView tvResolution = (TextView)v.findViewById(R.id.tvResolution);
	//
	// TextView tvFilename = (TextView)v.findViewById(R.id.tvFilename);
	// TextView tvDirectory = (TextView)v.findViewById(R.id.tvDirectory);
	// TextView tvDuration = (TextView)v.findViewById(R.id.tvDuration);
	// TextView tvDate = (TextView)v.findViewById(R.id.tvDate);
	//
	// tvDirectory.setText(new File(video.getPath()).getParent());
	// tvFilename.setText(video.getName());
	// tvDate.setText(video.getModifiedDate().toLocaleString());
	// tvResolution.setText(video.getResolution());
	// tvDuration.setText(video.getDurationString());
	// ivThumbnail.setImageBitmap(video.getThumbnail());
	//
	//
	// return v;
	// }
	// }

}
